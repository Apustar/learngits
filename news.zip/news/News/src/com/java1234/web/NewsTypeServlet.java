package com.java1234.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.java1234.dao.NewsDao;
import com.java1234.dao.NewsTypeDao;
import com.java1234.model.Link;
import com.java1234.model.NewsType;
import com.java1234.util.DbUtil;
import com.java1234.util.NavUtil;
import com.java1234.util.ResponseUtil;
import com.java1234.util.StringUtil;

public class NewsTypeServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	NewsDao newsDao=new NewsDao();
	NewsTypeDao newsTypeDao=new NewsTypeDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String action=request.getParameter("action");
		if("preSave".equals(action)){
			this.newsTypePreSave(request, response);
		}else if("save".equals(action)){
			this.newsTypeSave(request, response);
		}else if("backList".equals(action)){
			this.newsTypeBackList(request, response);
		}else if("delete".equals(action)){
			this.newsTypeDelete(request, response);
		}
		
	}

	
	private void newsTypePreSave(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String newsTypeId=request.getParameter("newsTypeId");
		Connection con=null;
		try{
			con=dbUtil.getCon();
			if(StringUtil.isNotEmpty(newsTypeId)){
				NewsType newsType=newsTypeDao.getNewsTypeById(con, newsTypeId);
				request.setAttribute("newsType", newsType);
			}
			
			if(StringUtil.isNotEmpty(newsTypeId)){
				request.setAttribute("navCode", NavUtil.genNewsManageNavigation("����������", "��������޸�"));
			}else{
				request.setAttribute("navCode", NavUtil.genNewsManageNavigation("����������", "�����������"));
			}
			request.setAttribute("mainPage", "/background/newsType/newsTypeSave.jsp");
			request.getRequestDispatcher("/background/mainTemp.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private void newsTypeSave(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection con=null;
		String newsTypeId=request.getParameter("newsTypeId");
		String typeName=request.getParameter("typeName");
		
		NewsType newsType=new NewsType(typeName);
		
		if(StringUtil.isNotEmpty(newsTypeId)){
			newsType.setNewsTypeId(Integer.parseInt(newsTypeId));
		}
		try{
			con=dbUtil.getCon();
			if(StringUtil.isNotEmpty(newsTypeId)){
				newsTypeDao.newsTypeUpdate(con, newsType);
			}else{
				newsTypeDao.newsTypeAdd(con, newsType);
			}
			request.getRequestDispatcher("/newsType?action=backList").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	private void newsTypeBackList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection con=null;
		try{
			con=dbUtil.getCon();
			List<NewsType> newsTypeBackList=newsTypeDao.newsTypeList(con);
			request.setAttribute("newsTypeBackList", newsTypeBackList);
			request.setAttribute("navCode", NavUtil.genNewsManageNavigation("����������", "�������ά��"));
			request.setAttribute("mainPage", "/background/newsType/newsTypeList.jsp");
			request.getRequestDispatcher("/background/mainTemp.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	private void newsTypeDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String newsTypeId=request.getParameter("newsTypeId");
		Connection con=null;
		try{
			con=dbUtil.getCon();
			JSONObject result=new JSONObject();
			boolean exist=newsDao.existNewsWithNewsTypeId(con, newsTypeId);
			if(exist){
				result.put("errorMsg", "����������������ţ�����ɾ�����������");
			}else{
				int delNums=newsTypeDao.newsTypeDelete(con, newsTypeId);
				if(delNums>0){
					result.put("success", true);
				}else{
					result.put("errorMsg", "ɾ��ʧ��");
				}
			}
			ResponseUtil.write(result, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
